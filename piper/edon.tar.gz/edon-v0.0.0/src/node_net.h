#ifndef NODE_NET
#define NODE_NET

#include <v8.h>

namespace node {

void InitNet(v8::Handle<v8::Object> target);

}

#endif  // NODE_NET
