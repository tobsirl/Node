exports.hello = require('./hello').hello;
