exports.hello = "world";
debug("load package/index.js");
