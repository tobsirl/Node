process.exit(process.argv[2] || 1);
